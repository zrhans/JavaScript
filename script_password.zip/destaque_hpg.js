// altere somente os nomes "teste" e "abrir"
//tambem altere os nomes dos arquivos que ele abrir�

function pass(){
if(document.password.nome.value=="teste" && document.password.senha.value=="abrir")
window.open('teste.htm','_blank')
else
window.open('teste1.htm','_self')
}